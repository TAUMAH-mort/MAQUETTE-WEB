document.addEventListener("DOMContentLoaded", function () {
    const dropdowns = document.querySelectorAll(".dropdown");

    dropdowns.forEach(function (dropdown) {
        dropdown.addEventListener("mouseenter", function () {
            this.querySelector(".dropdown-content").classList.add("show");
        });

        dropdown.addEventListener("mouseleave", function () {
            this.querySelector(".dropdown-content").classList.remove("show");
        });
    });
});

document.addEventListener("DOMContentLoaded", function () {
    $('.image-slider').slick({
        autoplay: true,
        dots: true,
        infinite: true,
        speed: 500,
        fade: true,
        cssEase: 'linear'
    });
});

document.addEventListener('DOMContentLoaded', function() {
    // Fonction pour initialiser la carte Google Maps
    function initMap() {
        var myLatLng = { lat: 47.401428330947276, lng: -0.45868154232793573 };
        var map = new google.maps.Map(document.getElementById('mini-map'), {
            center: myLatLng,
            zoom: 15,
        });

        // Ajoutez un marqueur à la position de votre boulangerie
        var marker = new google.maps.Marker({
            position: myLatLng,
            map: map,
            title: 'Le Fournil du Vignoble',
        });
    }
    // Appelez la fonction d'initialisation de la carte au chargement de la page
    initMap();

    // Fonction pour récupérer les avis Google
    async function getGoogleReviews() {
        const apiKey = 'AIzaSyD5RyleJemh7GmfipBM69WLOiqGYlpKlQQ';
        const placeId = 'ChIJmXFO0q_ZB0gRnial8WmwDOo'; // Remplacez cela par l'ID de votre boulangerie
        const url = `https://maps.googleapis.com/maps/api/place/details/json?placeid=${placeId}&key=${apiKey}`;

        try {
            const response = await fetch(url);
            const data = await response.json();
            console.log(data)

            if (data.status === 'OK' && data.result.reviews) {
                const reviewsContainer = document.getElementById('google-reviews');

                data.result.reviews.forEach(review => {
                    const reviewElement = createReviewElement(review);
                    reviewsContainer.appendChild(reviewElement);
                });
            } else {
                console.error('Erreur lors de la récupération des avis Google');
            }
        } catch (error) {
            console.error('Erreur lors de la récupération des avis Google', error);
        }
    }

    // Fonction pour créer un élément d'avis à partir des données
    function createReviewElement(review) {
        const reviewContainer = document.createElement('div');
        reviewContainer.classList.add('google-review');

        const ratingElement = document.createElement('p');
        ratingElement.textContent = `Note : ${review.rating}`;

        const authorElement = document.createElement('p');
        authorElement.textContent = `Avis par : ${review.author_name}`;

        const textElement = document.createElement('p');
        textElement.textContent = review.text;

        reviewContainer.appendChild(ratingElement);
        reviewContainer.appendChild(authorElement);
        reviewContainer.appendChild(textElement);

        return reviewContainer;
    }
    // Appelez la fonction pour récupérer les avis Google
    getGoogleReviews();
});