const express = require('express');
const cors = require('cors');

const app = express();

// Utilisez CORS comme middleware global
app.use(cors());

// ... autres configurations de votre serveur

// Démarrer le serveur
const port = 3000;
app.listen(port, () => {
    console.log(`Serveur en cours d'exécution sur le port ${port}`);
});

app.use(cors());
app.use(express.static('public'));

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/public/accueil.html');
});

app.get('/pains', (req, res) => {
  res.sendFile(__dirname + '/public/pains.html');
});

app.get('/viennoiseries', (req, res) => {
  res.sendFile(__dirname + '/public/viennoiseries.html');
});

app.get('/apropos', (req, res) => {
  res.sendFile(__dirname + '/public/apropos.html');
});

app.listen(port, () => {
  console.log(`Serveur en cours d'exécution sur le port ${port}`);
});
