document.addEventListener('DOMContentLoaded', function() {
    // Sélectionnez les éléments nécessaires
    var imageContainer = document.getElementById('image-container');
    var textContainer = document.getElementById('text-content');
    var plusBtn = document.getElementById('plus-btn');
    var minusBtn = document.getElementById('minus-btn');

    var images = imageContainer.getElementsByTagName('img');
    var currentIndex = 0;

    // Fonction pour afficher les images en diaporama
    function showSlides() {
        for (var i = 0; i < images.length; i++) {
            images[i].style.display = 'none';
        }

        currentIndex++;
        if (currentIndex >= images.length) {
            currentIndex = 0;
        }

        images[currentIndex].style.display = 'block';

        setTimeout(showSlides, 5000); // Changez d'image toutes les 5 secondes
    }

    // Ajoutez des événements aux boutons
    plusBtn.addEventListener('click', function() {
        textContainer.style.display = 'block';
    });

    minusBtn.addEventListener('click', function() {
        textContainer.style.display = 'none';
    });

    // Démarrez le diaporama lors du chargement de la page
    showSlides();
});